 <div class="five columns sidebar bottom-3">
   
     
     
     <!-- Categories Widget -->
     <div class="widget categories">
       
       <ul class="arrow-list">
         <li><a href="#">Edit Profile </a></li>
         <li><a href="upload.php">Upload</a></li>
         <li><a href="viewuploads.php">View Upload</a></li>
         <li><a href="viewfrontnews.php">View News</a></li>
         <li><a href="viewfrontdownloads.php">View Download</a></li>
         <li><a href="#">Feedback</a></li>
       </ul><!-- End arrow-list -->
     </div>
     <!-- End -->
     
   
   </div><!-- End Sidebar Widgets -->
        