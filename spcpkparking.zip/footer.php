 <footer>
   
     
     
     <div class="footer-down">
      <div class="container clearfix">
        
        <div class="eight columns">
         <span class="copyright">
         &copy; Copyright <?php echo date('Y');?> <a href="index.php">Online Parking Portal</a>. All Rights Reserved.
        </div><!-- End copyright -->
        
        <div class="eight columns">
          <div class="social">
          <a href="#"><i class="social_icon-twitter s-14"></i></a>
           <a href="#"><i class="social_icon-facebook s-18"></i></a>
           <a href="#"><i class="social_icon-dribbble s-18"></i></a>
           <a href="#"><i class="social_icon-gplus s-18"></i></a>
           <a href="#"><i class="social_icon-pinterest s-18"></i></a>
           <a href="#"><i class="social_icon-youtube s-18"></i></a>
           <a href="#"><i class="social_icon-rss s-18"></i></a>
          </div>
        </div><!-- End social icons -->
        
      </div><!-- End container -->
     </div><!-- End footer-top -->
     
   </footer><!-- <<< End Footer >>> -->