<?php

error_reporting(0);
session_start();

require_once "../inc/config.php";
require_once "../inc/dbhelper.php";

class AdminHelper
{
    function checkUser()
    {

        $username = $_POST['username'];
        $password = $_POST['password'];


        $db = new Database();

        $db->open();

        $msg = '';

        $sql = "SELECT * FROM `users` WHERE username='" . $username . "' AND password='" . $password . "' AND `published`=1";
        $result = $db->query($sql);

        $row = $db->fetchobject($result);


        if ($row)
        {

            $_SESSION['aid'] = $row->id;
            $_SESSION['ausername'] = $row->username;
            echo "<script>window.location = 'dashboard.php';</script>";
        } 
        else
        {

            $msg = "Invalid Details";

        }
        return $msg;
    }

    function getParkers()
    {
        $helper = new AdminHelper();

        $db = new Database();

        $db->open();
        $sql = '';


        $sql = "SELECT * FROM `parkers` ORDER BY id DESC"; 
        $result = $db->query($sql);

        if($db->numOfRecords())
        {
            ?>
            <table class="table table-bordered" align="left" cellpadding="5px" cellspacing="5px" border="1px">
                <tr>
                    <th>First name</th>
                    <th>Last name</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Mobile</th>
                    <th style="text-align: center;">Published</th>
                    <th style="text-align:center;">Remove</th>
                </tr>    

                <?php
                while ($row = $db->fetcharray($result))
                {
                    ?>

                     <tr>

            	        <td><?php echo $row['first_name'];?></td>
                        <td><?php echo $row['last_name'];?></td>
            			<td><?php echo $row['username'];?></td>
            		    <td><?php echo $row['email'];?></td>
            			<td><?php echo $row['mobile'];?></td>
                        <td style="text-align:center;">
                            <?php
                                if ($row['published'])
                                {
                                    ?>
                                    <a href="viewparkers.php?id=<?php echo $row['id'];?>&published=0&task=status"><img  src="../images/tick.png" alt="" /></a>
                                    <?php
                
                                } 
                                else
                                {
                                    ?>
                                    <a href="viewparkers.php?id=<?php echo $row['id'];?>&published=1&task=status"><img src="../images/publish_x.png" alt="" /></a>
                                    <?php
                
                                }
                                ?>
                        </td>
                        <td style="text-align:center;">
                            <a href="viewparkers.php?id=<?php echo $row['id'];?>&task=remove"><img src="../images/delete.png" alt="Remove" /></a>
                        </td>
                   </tr> 
                    <?php
                }
                ?>
            </table>
            <?php

        } 
        else
        {
            ?>
            No Parkers found
            <?php
        }
    }

    function updateStatus($id)
    {
        $db = new Database();
        $db->open();

        $sql = "UPDATE `parkers` SET `published` = '" . $_GET['published'] . "' WHERE `id` =" . $id;
        $result = $db->query($sql);


        if ($result)
        {

            if ($_GET['published'] == "1")
            {
                return "Parker Status Updated.";

            }

        } 
        else
        {
            return "Parker Status Not Updated.";
        }
    }

    function removeParker($id)
    {
        $db = new Database();
        $db->open();

        $sql = "DELETE FROM `parkers` WHERE `id` =" . $id;
        $result = $db->query($sql);

        if ($result)
        {
            return "Parker Removed.";
        } 
        else
        {
            return "Parker Not Removed.";
        }
    }
    
    function addParkingSpace()
    {
        $city           = $_POST['city'];
        $address        = $_POST['address'];
        $no_of_slots    = $_POST['no_of_slots'];
        $amount_per_hour= $_POST['amount_per_hour'];
        $published      = $_POST['published'];
        $id             = $_POST['id'];

        $db = new Database();
        $db->open();

        $msg = '';
        $sql = '';

        if($id) 
        {
            $sql = "UPDATE `parking_spaces` SET `city`='" . $city . "', `address`='" . $address . "', `no_of_slots`='" . $no_of_slots ."', `amount_per_hour`='" . $amount_per_hour . "', `published` = '" . $published . "' WHERE `id`=" . $id;
            $result = $db->query($sql);
            
            if($result)
            {
                return "Parking Space updated successfully.";
            }
            else
            {
                return  "Parking Space not updated successfully.";
            }
        } 
        else 
        {
            $sql = "INSERT INTO `parking_spaces` (`id`, `city`, `address`, `no_of_slots`, `amount_per_hour`, `published`) VALUES (NULL, '" .$city . "', '" . $address . "', '" . $no_of_slots . "', '" . $amount_per_hour . "', '" . $published . "');";
            $result = $db->query($sql);

            if($result)
            {
                return "Parking Space added successfully.";
            }
            else
            {
                return  "Parking Space not added successfully.";
            }
        }
    }
    
    function getParkingSpaces()
    {
        $helper = new AdminHelper();

        $db = new Database();

        $db->open();
        $sql = '';


        $sql = "SELECT * FROM `parking_spaces` ORDER BY id DESC"; 
        $result = $db->query($sql);

        if($db->numOfRecords())
        {
            ?>
            <table class="table table-bordered" align="left" cellpadding="5px" cellspacing="5px" border="1px">
                <tr>
                    <th>City</th>
                    <th>Address</th>
                    <th>Number of Slots</th>
                    <th>Amount Per Hour</th>
                    <th style="text-align: center;">Published</th>
                    <th style="text-align:center;">Remove</th>
                </tr>    

                <?php
                while ($row = $db->fetcharray($result))
                {
                    ?>

                     <tr>

            	        <td><?php echo $row['city'];?></td>
                        <td><?php echo $row['address'];?></td>
            			<td><?php echo $row['no_of_slots'];?></td>
            		    <td><?php echo $row['amount_per_hour'];?></td>
                        <td style="text-align:center;">
                            <?php
                                if ($row['published'])
                                {
                                    ?>
                                    <a href="parkingspaces.php?id=<?php echo $row['id'];?>&published=0&task=status"><img  src="../images/tick.png" alt="" /></a>
                                    <?php
                
                                } 
                                else
                                {
                                    ?>
                                    <a href="parkingspaces.php?id=<?php echo $row['id'];?>&published=1&task=status"><img src="../images/publish_x.png" alt="" /></a>
                                    <?php
                
                                }
                                ?>
                        </td>
                        <td style="text-align:center;">
                            <a href="parkingspaces.php?id=<?php echo $row['id'];?>&task=remove"><img src="../images/delete.png" alt="Remove" /></a>
                        </td>
                   </tr> 
                    <?php
                }
                ?>
            </table>
            <?php

        } 
        else
        {
            ?>
            No Parking Spaces found
            <?php
        }
    }
    
    function updateParkingSpaceStatus($id)
    {
        $db = new Database();
        $db->open();

        $sql = "UPDATE `parking_spaces` SET `published` = '" . $_GET['published'] . "' WHERE `id` =" . $id;
        $result = $db->query($sql);


        if ($result)
        {

            if ($_GET['published'] == "1")
            {
                return "Parking Space Status Updated.";
            }

        } 
        else
        {
            return "Parking Space Status Not Updated.";
        }
    }

    function removeParkingSpace($id)
    {
        $db = new Database();
        $db->open();

        $sql = "DELETE FROM `parking_spaces` WHERE `id` =" . $id;
        $result = $db->query($sql);

        if ($result)
        {
            return "Parking Space Removed.";
        } 
        else
        {
            return "Parking Space Not Removed.";
        }
    }
    
    function getReservations()
    {
        $db = new Database();

        $db->open();
        $sql = '';


        $sql = "SELECT a.*, b.first_name, b.last_name, b.mobile FROM `reservations` as a JOIN `parkers` as b ON a.parker_id = b.id ORDER BY id DESC"; 
        $result = $db->query($sql);

        if($db->numOfRecords())
        {
            ?>
            <table class="table table-bordered" align="left" cellpadding="5px" cellspacing="5px" border="1px">
                <tr>
                    <th>Name</th>
                    <th>Mobile</th>
                    <th>From Date</th>
                    <th>To Date</th>
                    <th>City</th>
                    <th>Address</th>
                    <th>Slot Names</th>
                    <th style="text-align: center;">No. of Slots</th>
                    <th style="text-align:center;">Hours</th>
                    <th style="text-align:center;">Amount Per Hour</th>
                    <th>Amount To Pay</th>
                    <th>Remove</th>
                </tr>    

                <?php
                while ($row = $db->fetcharray($result))
                {
                    ?>
                     <tr>
                        <td><?php echo $row['first_name']." ".$row['last_name'];?></td>
            		    <td><?php echo $row['mobile'];?></td>
            	        <td><?php echo date('d/m/Y g:i a', strtotime($row['from_date']));?></td>
                        <td><?php echo date('d/m/Y g:i a', strtotime($row['to_date']));?></td>
            			<td><?php echo $row['city'];?></td>
            		    <td><?php echo $row['address'];?></td>
            			<td><?php echo $row['slots'];?></td>
                        <td style="text-align:center;"><?php echo $row['no_of_slots'];?></td>
                        <td style="text-align:center;"><?php echo $row['hours'];?></td>
                        <td style="text-align:center;"><?php echo $row['amount_per_hour'];?></td>
                        <td style="text-align:center;"><?php echo round($row['amount'], 0);?></td>
                        <td style="text-align:center;">
                            <a href="viewreservations.php?id=<?php echo $row['id'];?>&task=remove"><img src="../images/delete.png" alt="Remove" /></a>
                        </td>
                   </tr> 
                    <?php
                }
                ?>
            </table>
            <?php

        } 
        else
        {
            ?>
            No Reservations found.
            <?php
        }
    }
    
    function removeReservation($id)
    {
        $db = new Database();
        $db->open();

        $sql = "DELETE FROM `reservations` WHERE `id` =" . $id;
        $result = $db->query($sql);

        if ($result)
        {
            return "Reservation Removed.";
        } 
        else
        {
            return "Reservation Not Removed.";
        }
    }

}

?>