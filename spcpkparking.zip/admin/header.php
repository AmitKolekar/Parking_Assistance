 <?php

    error_reporting(0);

    session_start();

 ?>

 <header class="style-3">

     <div class="top-bar">

       <div class="container clearfix">

        <div class="slidedown">

        

         <div class="eight columns">

           <div class="phone-mail">

             <a><i class="icon-phone"></i> Phone : +1234567890</a>

             <a href="info@parkingportal.com"><i class="icon-envelope-alt"></i> Mail : info@parkingportal.com</a>

           </div><!-- End phone-mail -->

         </div>

         <div class="eight columns">

           <div class="social" style="margin-top: 7px;">

           <?php

                if($_SESSION['aid']!='')

                {

                    echo  "Welcome | ".$_SESSION['ausername']." <a href='logout.php'>Logout</a>";     

                }

               

           ?>

           

          

           </div>

          </div><!-- End social-icons -->

          

         </div><!-- End slidedown -->

       </div><!-- End Container -->

       

     </div><!-- End top-bar -->

     

     <div class="main-header">

       <div class="container clearfix">

         <a href="#" class="down-button"><i class="icon-angle-down"></i></a><!-- this appear on small devices -->

         <div class="eleven columns">

          <div class="logo">

          <a href="index.php">

            <h3>Online Parking Portal Admin Panel</h3>

          </a>

          </div>

         </div><!-- End Logo -->

         

         

       

       </div><!-- End Container -->

     </div><!-- End main-header -->

     

     <div class="down-header">

       <div class="container clearfix">

       

            <?php

            

                

                if($_SESSION['aid']!='')

                {

                    ?>

                    <div class="sixteen columns">

                       <nav id="menu" class="navigation" role="navigation">
    
                          <a href="#">Show navigation</a><!-- this appear on small devices -->
    
                          <ul id="nav">
                            <li class="active"><a href="dashboard.php">Home</a></li>
                            <li><a href="viewreservations.php">View Reservations</a></li>
                            <li><a href="viewparkers.php">View Parkers</a></li>
                            <li>
                                <a href="parkingspaces.php">Parking Spaces</a>
                                <ul>
                                   <li><a href="parkingspaces.php">Parking Spaces</a></li>
                                   <li><a href="addparkingspace.php">Add Parking Space</a></li>
                              </ul>
                            </li>
                            
                          </ul>
                        </nav>
                    </div><!-- End Menu -->
                    <?php 

                }

            ?>

       

      </div><!-- End Container -->

     </div><!-- End down-header -->

     

   </header><!-- <<< End Header >>> --> 

  