<?php
    
error_reporting(0);

require_once "adminhelper.php";
$helper=new AdminHelper();
    
?>
  
<!-- Start Sidebar Widgets -->
<div class="five columns sidebar bottom-3">
 
 <!-- Categories Widget -->
 <div class="widget categories">
   <h3 class="title bottom-1">Menu</h3><!-- Title Widget -->
   <ul class="arrow-list">
       
     <li><a href="addnews.php">Add News</a></li>
     <li><a href="viewnews.php">View News</a></li>
     
   </ul><!-- End arrow-list -->
 </div>
 <!-- End -->
 
</div><!-- End Sidebar Widgets -->